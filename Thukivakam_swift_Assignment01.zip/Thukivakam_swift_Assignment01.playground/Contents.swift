import UIKit

//Question-01
print("The first version of the Swift programming language was introduced by Apple at the Apple Worldwide Developers Conference(WWDC) on June 2,2014")
print("-----------------------------------------------------------------------------------------------")

//Question-02
let pi:Double=3.14
let radius:Double=7.5
let circumference=2*pi*radius
print(circumference)
print("-----------------------------------------------------------------------------------------------")

//Question-03
var fahrenheit:Double=98.8
var celsius:Double=(fahrenheit-32)*5/9
celsius=(celsius*100).rounded()/100
print("Fahrenheit: \(fahrenheit) F\nCelsius:    \(celsius) C")
print("-----------------------------------------------------------------------------------------------")

//Question-04
print("Hello All, my name is Sravanthi Thukivakam.", terminator: "")
print("I am intrested to work as a Data Analyst and worked in Deloitte as a Data Analyst.")
print("I am from Andhra Pradesh, India.")
print("-----------------------------------------------------------------------------------------------")

//Question-05
print("Swift is a powerful and intuitive programming language for iOS, iPadOS, macOS, tvOS, and watchOS.\nWriting Swift code is interactive and fun, the syntax is concise yet expressive, and Swift includes modern features\tdevelopers love.\nSwift code is safe by design and produces software that runs lightning-fast.")
print("----------------------------------------------------------------------------------------------")

//Question-06
var number=54304100
var count=String(number).count
print("The number \(number) has \(count) digits.")
print("----------------------------------------------------------------------------------------------")

//Question-07
let str="Welcome to iOS Class"
var result=""
for char in str{
    if String(char) != " "{
        result+=String(char)+","
    }
}

if !result.isEmpty {
    result.removeLast()
}

print(result)
print("----------------------------------------------------------------------------------------------")


