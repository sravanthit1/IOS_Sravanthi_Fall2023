//
//  ViewController.swift
//  Thukivakam_WordGuess
//
//  Created by Thukivakam,Sravanthi on 10/17/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var wordsGuessedLabel: UILabel!
    
    @IBOutlet weak var wordsRemainingLabel: UILabel!
    
    @IBOutlet weak var totalWordsLabel: UILabel!
    
    @IBOutlet weak var userGuessLabel: UILabel!
    
    @IBOutlet weak var guessLetterField: UITextField!
    
    @IBOutlet weak var guessBtn: UIButton!
    
    @IBOutlet weak var playAgainBtn: UIButton!
    
    var guess : String = ""
    var right=false
    var wordLevel : Int = 0
    var NoofWords = 0
    var remaining = 5
    var flg = false
    var ResetFlag = false
    var word = ""
    var guessed = 0
    let maxNumOfWrongGuesses = 10
    var updatedStr=""
    var count=0
    var hintword=""
    var inp=""
    var image = [["goa","tropical paradise ,coastal bliss", "goa"],["kerala","god's own place in India","kerala"],["guntur","A place where red chillies are famous","guntur"],["banglore","garden city of India","banglore"],["vizag","the city of destiny","vizag"]]
    
    @IBAction func guessLetterButtonPressed(_ sender: UIButton) {

        if(count<maxNumOfWrongGuesses){
            
            print(inp)
            word=word+inp
            count=count+1
            
            updatedStr=""
            hintword=image[wordLevel][0].uppercased()
            //print(hintword)
            print(hintword.contains(word.uppercased()))
            //check if the entered char is in the word
            if(hintword.contains(word.uppercased())){
                for l in hintword {
                    if(word.uppercased().contains(l.uppercased())) {
                        updatedStr+="\(l.uppercased())"
                    }
                    else {
                        updatedStr+="_ "
                    }
                }
                userGuessLabel.text=updatedStr
            }else{
                guessed=guessed+1
            }
            
            //check if the guessed word is matched with the word
            if userGuessLabel.text!.contains("_") == false{
                guessBtn.isEnabled=false
                displayImage.isHidden=false
                displayImage.image=UIImage(named: image[wordLevel][2])
                
                
                guessCountLabel.text="Wow! You have made \(count) guesses to guess the word!"
                playAgainBtn.isHidden=false
                playAgainBtn.isEnabled=true
                remaining=remaining-1
                wordLevel=wordLevel+1
                guessLetterField.text=""
                
                wordsGuessedLabel.text="Total number of words guessed successfully: \(wordLevel)"
                wordsRemainingLabel.text="Total number of words remaining in game: \(remaining)"
                totalWordsLabel.text="Total number of words in game: 5"
                //updateUser(l:wordLevel)
                word=""
                count=0
                guessed=0
            }else{
                guessCountLabel.text="You have made \(count) guesses"
            }}
        
        
        else{
            guessCountLabel.text="You have used all the available guesses, Please play again"
                playAgainBtn.isHidden=false
                playAgainBtn.isEnabled=true
        }
        
        
        
            /*
            if(guessed>maxNumOfWrongGuesses){
                var inp=guessLetterField.text?.suffix(1)
                word=word+inp!
                for l in image[wordLevel][0] {
                    if(word.uppercased().contains(l.uppercased())) {
                        updatedStr+="\(l.uppercased())"
                    }
                    else {
                        updatedStr+="_ "
                    }
                }
                userGuessLabel.text="\(updatedStr)"
                if userGuessLabel.text!.contains("_") == false{
                    playAgainBtn.isHidden = false;
                    
                }else{
                    displayImage.image=UIImage(named: image[wordLevel][2])
                    guessCountLabel.text="Wow! You have made \(guessed) guesses to guess the word!"
                    playAgainBtn.isHidden=false
                    playAgainBtn.isEnabled=true
                    remaining=remaining-1
                    wordLevel=wordLevel+1
                }}
            else{
            guessCountLabel.text="You have used all the available guesses, Please play again"
                playAgainBtn.isHidden=false
                playAgainBtn.isEnabled=true
            }*/
            
        
    }
    
    
    /*func updateGuessedWord(guessedWord: String, originalWord: String, letter: String) -> String {
        var updatedWord = guessedWord
        for (index, char) in originalWord.enumerated() {
            if String(char) == letter {
                let startIndex = updatedWord.index(updatedWord.startIndex, offsetBy: 2 * index)
                updatedWord.replaceSubrange(startIndex...startIndex, with: letter)
            }
        }
        return updatedWord
    }*/
    
    @IBOutlet weak var hintLabel: UILabel!
    
    @IBOutlet weak var guessCountLabel: UILabel!
    
    @IBOutlet weak var statusLabel: UILabel!
    
    
    @IBAction func playAgainButtonPressed(_ sender: UIButton) {
        updateUser(l:wordLevel)
        
        if(NoofWords==5 && remaining ==  0) {
            statusLabel.text="Congratulations! You are done with the game! Please start over again"
            displayImage.image = UIImage(named: "All")
        }
        
    }
    
    @IBOutlet weak var displayImage: UIImageView!
    
    
    @IBAction func CharEntered(_ sender: UITextField) {
        
        inp=guessLetterField.text!
        
        if(inp.isEmpty) {
            guessBtn.isEnabled = false
        }
        else {
            guessBtn.isEnabled = true
            sender.text = String(inp.suffix(0)).uppercased()
        }
    }
    
    
    
    func updateUser(l:Int){
        wordsGuessedLabel.text="Total number of words guessed successfully: \(wordLevel)"
        wordsRemainingLabel.text="Total number of words remaining in game: \(remaining)"
        totalWordsLabel.text="Total number of words in game: 5"
        guessCountLabel.text = "You have made 0 guesses"
        displayImage.isHidden=true
        
        var ans=""
        let str=image[l][0]
        for _ in str{
            ans=ans+"_"+" "
        }
        userGuessLabel.text="\(ans)"
        hintLabel.text="Hint: \(image[l][1])"
        updatedStr=""
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        updateUser(l: wordLevel)
        
        guessCountLabel.text = "You have made 0 guesses"
        statusLabel.isEnabled=false
        playAgainBtn.isHidden=true
        playAgainBtn.isEnabled=false
        
        guessBtn.isEnabled = false
        guessLetterField.addTarget(self, action: #selector(CharEntered(_:)), for: .editingChanged)

    }


}

