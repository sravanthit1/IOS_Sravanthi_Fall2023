//
//  ViewController.swift
//  Thukivakam_Assignment02
//
//  Created by Sravanthi Thukivakam on 9/8/23.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var nameL: UILabel!
    
    @IBOutlet weak var billAmountL: UILabel!
    
    @IBOutlet weak var tipL: UILabel!
    
    @IBOutlet weak var nameOutlet: UITextField!
    
    @IBOutlet weak var billAmountOutlet: UITextField!
    
    @IBOutlet weak var tipPercentageOutlet: UITextField!
    
    @IBOutlet weak var receiptL: UILabel!
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var billAmountLabel: UILabel!
    
    @IBOutlet weak var tipAmountLabel: UILabel!
    
    @IBOutlet weak var totalAmountLabel: UILabel!
    
    @IBAction func SubmitBTN(_ sender: UIButton) {
        //read input from name, billAmount and Tip and store in variables.
        var nameinp=nameOutlet.text!
        let bill=billAmountOutlet.text!
        let tip=tipPercentageOutlet.text!
        
        //convert bill and tip to double
        let billinp=Double(bill)!
        let tipinp=Double(tip)!
        
        //calculate tip based on percentage
        let tipAmt=(billinp*tipinp)/100.0;
        
        //final bill calculation
        let total=billinp+tipAmt;
        
        //calculate total amount and assign it to respective ouput labels
        nameLabel.text="Name: \(nameinp)";
        billAmountLabel.text="Bill Amount: $\(billinp)";
        tipAmountLabel.text="Tip Amount: $\(tipAmt)";
        totalAmountLabel.text="Total Amount: $\(total)";
    }
    
    @IBAction func ResetBTN(_ sender: UIButton) {
        nameOutlet.text=""
        billAmountOutlet.text=""
        tipPercentageOutlet.text=""
        
        nameLabel.text=""
        billAmountLabel.text=""
        tipAmountLabel.text=""
        totalAmountLabel.text=""
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

