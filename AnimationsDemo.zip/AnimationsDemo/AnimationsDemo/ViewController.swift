//
//  ViewController.swift
//  AnimationsDemo
//
//  Created by Thukivakam,Sravanthi on 10/24/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var displayImage: UIImageView!
    
    @IBOutlet weak var happyBtn: UIButton!
    
    @IBOutlet weak var sadBtn: UIButton!
    
    @IBOutlet weak var angryBtn: UIButton!
    
    @IBOutlet weak var shakeMeBtn: UIButton!
    
    @IBOutlet weak var showMeBtn: UIButton!
    
    @IBAction func happyBtnClicked(_ sender: UIButton) {
        UpdateandAnimate("happy")
    }
    
    @IBAction func sadBtnClicked(_ sender: UIButton) {
        UpdateandAnimate("sad")
    }
    
    @IBAction func angryBtnClicked(_ sender: UIButton) {
        UpdateandAnimate("angry")
    }
    
    @IBAction func shakeMeBtnClicked(_ sender: UIButton) {
        var width=displayImage.frame.width
        
        width+=40
        
        var height=displayImage.frame.height
        
        height+=40
        
        var x=displayImage.frame.origin.x-20
        
        var y=displayImage.frame.origin.y-20
        
        var largeFrame=CGRect(x: x, y:y, width:width, height:height)
        
        UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.4, initialSpringVelocity: 50, animations: {
            self.displayImage.frame=largeFrame
        })
    }
    
    @IBAction func showMeBtnClicked(_ sender: UIButton) {
        UIView.animate(withDuration: 1, animations: {
            
            //moving all components to the center
            self.displayImage.center.x=self.view.center.x
            
            self.happyBtn.center.x=self.view.center.x
            
            self.sadBtn.center.x=self.view.center.x
            
            self.angryBtn.center.x=self.view.center.x
            
            self.shakeMeBtn.center.x=self.view.center.x
            
        })
        //disable the show Me btn
        showMeBtn.isEnabled=false
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func viewDidAppear(_ animated: Bool) {
        //Move the image view outside of screen view
        displayImage.frame.origin.x=view.frame.maxX
        
        //Move other components outside of the screen
        happyBtn.frame.origin.x=view.frame.width
        
        sadBtn.frame.origin.x=view.frame.width
        
        angryBtn.frame.origin.x=view.frame.width
        
        shakeMeBtn.frame.origin.x=view.frame.width
        
    }
    
    func UpdateandAnimate(_ imageName:String)
    {
        //make the image opaque(alpha =0)
        UIView.animate(withDuration: 1, animations: {
            self.displayImage.alpha=0
        })
        
        //assign the new image with animation and make it transparent(aplha=1)
        UIView.animate(withDuration: 1, delay: 0.5, animations: {
            self.displayImage.alpha=1
            self.displayImage.image=UIImage(named: imageName)
        })
        
    }

}

