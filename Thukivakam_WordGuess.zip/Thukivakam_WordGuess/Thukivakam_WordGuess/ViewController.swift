//
//  ViewController.swift
//  Thukivakam_WordGuess
//
//  Created by Thukivakam,Sravanthi on 10/17/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var wordsGuessedLabel: UILabel!
    
    @IBOutlet weak var wordsRemainingLabel: UILabel!
    
    @IBOutlet weak var totalWordsLabel: UILabel!
    
    @IBOutlet weak var userGuessLabel: UILabel!
    
    @IBOutlet weak var guessLetterField: UITextField!
    
    @IBOutlet weak var guessBtn: UIButton!
    
    @IBOutlet weak var playAgainBtn: UIButton!
    
    var guess : String = ""
    var right=false
    var wordLevel : Int = 0
    var NoofWords = 0
    var remaining = 5
    var flg = false
    var ResetFlag = false
    var words = ""
    var guessed = 0
    let maxNumOfWrongGuesses = 10
    var image = [["chennai","Capital of TamilNadu", "chennai"],["kerala","god's own place in India","kerala"],["guntur","A place where red chillies are famous","guntur"],["banglore","garden city of India","banglore"],["vizag","the city of destiny","vizag"]]
    
    @IBAction func guessLetterButtonPressed(_ sender: UIButton) {
        if(remaining>0){
            guessed=guessed+1
            if(guessed<maxNumOfWrongGuesses){
                // if(wordLevel==0){
                var InputText = guessLetterField.text!.last
                words = "\(words)\(InputText!)"
                var FormedString = ""
                for l in words {
                    if(words.uppercased().contains(l.uppercased())) {
                        FormedString+="\(l.uppercased())"
                    }
                    else {
                        FormedString+="_ "
                    }
                    
                }
                userGuessLabel.text = "\(FormedString)"
                
                if(!(FormedString.elementsEqual(image[wordLevel][0].uppercased()))) {
                    guessCountLabel.text="You have made \(guessed) guesses"
                }else{
                    displayImage.image=UIImage(named: image[wordLevel][2])
                    guessCountLabel.text="Wow! You have made \(guessed) guesses to guess the word!"
                    NoofWords=NoofWords+1
                    wordLevel=wordLevel+1
                    remaining=remaining-1
                    playAgainBtn.isHidden=false
                    playAgainBtn.isEnabled=true
                    
                }
                
            }else{
                guessCountLabel.text="You have used all the available guesses, Please play again"
                playAgainBtn.isEnabled=true
            }}else{
                statusLabel.text="Congratulations! You are done with the game! \n Please start over again"
            }
        
        /*
        guessed+=1
        if(guessed < maxNumOfWrongGuesses) {
            var InputText = guessLetterField.text!.last
            words = "\(words)\(InputText!)"
            var FormedString = ""
            for l in guess {
                if(words.uppercased().contains(l.uppercased())) {
                    FormedString+="\(l.uppercased())"
                }
                else {
                    FormedString+="_ "
                }
                
            }
            userGuessLabel.text = FormedString
            
            if(!userGuessLabel.text!.contains("_")) {
                NoofWords+=1
                remaining-=1
                guessCountLabel.text = "Wow! You have made \(guessed) guesses to guess the word!"
                wordsGuessedLabel.text = "Total Number of words guessed successfully: \(NoofWords)"
                wordsRemainingLabel.text = "Total number of words remaining in game: \(remaining)"
                totalWordsLabel.text = "Total number of words in game: 5"
               
                
                    displayImage.image = UIImage(named: image[wordLevel][2])
                   
                
                playAgainBtn.isHidden = false
                guessLetterField.text = ""
                guessBtn.isEnabled = false
                
            }
            else {
                guessCountLabel.text = "You have made \(guessed) guesses"
                playAgainBtn.isHidden = true
            }
        }
        else {
            guessCountLabel.text = "You have used all the available guesses,Please play again"
            playAgainBtn.isHidden = false
            guessed=0
        }*/
    }
    
    func updateGuessedWord(guessedWord: String, originalWord: String, letter: String) -> String {
        var updatedWord = guessedWord
        for (index, char) in originalWord.enumerated() {
            if String(char) == letter {
                let startIndex = updatedWord.index(updatedWord.startIndex, offsetBy: 2 * index)
                updatedWord.replaceSubrange(startIndex...startIndex, with: letter)
            }
        }
        return updatedWord
    }
    
    @IBOutlet weak var hintLabel: UILabel!
    
    @IBOutlet weak var guessCountLabel: UILabel!
    
    @IBOutlet weak var statusLabel: UILabel!
    
    
    @IBAction func playAgainButtonPressed(_ sender: UIButton) {
        updateUser(l:wordLevel)
        
        if(NoofWords==5 && remaining ==  0 && ResetFlag==false) {
            statusLabel.text="Congratulations! You are done with the game! Please start over again"
            displayImage.image = UIImage(named: "All")
            flg = true
        }
        /*
        if(flg==false) {
            
            if(!userGuessLabel.text!.contains("_")) {
                guessed = 0
                wordLevel+=1
                words=""
                guess = image[wordLevel][0]
                hintLabel.text = "Hint: \(image[wordLevel][1])"
                var i = 0
                var str = ""
                
                while(i<guess.count) {
                    str = "\(str) _ "
                    i=i+1
                }
                userGuessLabel.text = str
                statusLabel.text = ""
                playAgainBtn.isHidden = true
                guessLetterField.text=""
            }
            else {
                playAgainBtn.isHidden=true
            }
            displayImage.image=UIImage(named: "")
        }
        else {
            if(ResetFlag==true) {
                Rset()
            }
            else {
                ResetFlag = true
            }
        }*/
    }
    
    @IBOutlet weak var displayImage: UIImageView!
    
    
    @IBAction func CharEntered(_ sender: UITextField) {
        let str=guessLetterField.text!
        if(str.isEmpty) {
            guessBtn.isEnabled = false
        }
        else {
            guessBtn.isEnabled = true
        }
    }
    
    /*func Rset() {
        wordLevel = 0
        words = ""
        guessed = 0
        flg = false
        ResetFlag = false
        guessLetterField.text=""
        playAgainBtn.isHidden=true
        guess = image[wordLevel][0]
        // Do any additional setup after loading the view.
        wordsGuessedLabel.text = "Total Number of words guessed successfully: 0"
        wordsRemainingLabel.text = "Total number of words remaining in game: 5"
        totalWordsLabel.text = "Total number of words in game: 5"
        guessBtn.isEnabled = false
        var firstWord = image[wordLevel][0]
        hintLabel.text = "Hint: \(image[wordLevel][1])"
        var i = 0
        var str = ""
        
        while(i<firstWord.count) {
            str = "\(str) _ "
            i=i+1
        }
        userGuessLabel.text = str
        statusLabel.text = ""
        guessCountLabel.text = "You have made \(guessed) guesses"
        displayImage.image = UIImage(named: "")
        NoofWords = 0
        remaining = 5
        
    }*/
    
    func updateUser(l:Int){
        wordsGuessedLabel.text="Total number of words guessed successfully: \(wordLevel)"
        wordsRemainingLabel.text="Total number of words remaining in game: \(remaining)"
        totalWordsLabel.text="Total number of words in game: 5"
        
        var ans=""
        let str=image[l][0]
        for _ in str{
            ans=ans+"_"+" "
        }
        userGuessLabel.text="\(ans)"
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //wordsGuessedLabel.text="Total number of words guessed successfully: 0"
       // wordsRemainingLabel.text="Total number of words remaining in game: 5"
        //totalWordsLabel.text="Total number of words in game: 5"
        updateUser(l: wordLevel)
        hintLabel.text = "Hint: \(image[0][1])"
        guessCountLabel.text = "You have made 0 guesses"
        statusLabel.isEnabled=false
        playAgainBtn.isHidden=true
        playAgainBtn.isEnabled=false
        
        guessBtn.isEnabled = false
        guessLetterField.addTarget(self, action: #selector(CharEntered(_:)), for: .editingChanged)

    }


}

