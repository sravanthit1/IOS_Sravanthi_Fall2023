import UIKit

var greeting = "Hello, playground"
print("Hello,class!");
print("I am a Graduate Student at Northwest Missouri State University");
print("I love gardening and like to explore new things.");

print("Hi",10,12.25)
var programmingLanguage = "Swift"
print("My favourite programming language is \(programmingLanguage)")
var salary = 90000;
//same data type can be concatenated
print(20000+salary)
//interpolation is used for diff data types
print("My salary is \(salary)")
print("""
Hello
World!
""")
print("Hello All,\rWelcome to swift programming")
let welcomeMessage : String = "Hello!"
print(welcomeMessage , "All")
//trying to change constant
//welcomeMessage = "Hey!"
print(welcomeMessage , "How are you?")
print(1,"Hello",78.9,terminator: "$")

print("Welcome to swift programming")
print("Fall 2023")
print("*****************************")
print("Welcome to swift programming" , terminator : "-" )
print("Fall 2023")

print("The list of numbers are ")
print(1,2,3,4,5,6)
print("The new pattern is")
print(1,2,3,4,5,6, separator: "-")


print("****** WORKSHEET -2 ******")
var mobileBrand = "Apple"
mobileBrand = "Samsung"
print(mobileBrand)

let pi = 3.14
print(pi)
//pi = 23.22
//print(pi)
//cannot change constant so it throws error

var age : Int = 23
age = age * 2
print(age)

var aweMessage = "This is Superb!"
print(aweMessage)
print("aweMessage")

var c1 = "IOS"
var c2 = "Java"
print(c1,c2)
print(c1,"-",c2)

print(10,20,30)
print(12.5,15.5)

print("WORKSHEET 3")
var httpError = (errorCode : 404 , errorMessage : "Page Not Found")
print(httpError)
print(httpError.errorCode , terminator : ": ")
print(httpError.errorMessage)

var name = ("John","Smith")
var fName = name.0
var lName = name.1
print(fName , terminator : ", ")
print(lName)

var origin = (x : 0 , y : 0)
var point = origin
print(point)

let city = (name : "Maryville" , population : 11,000)
let( cityName ,cityPopulation ) = (city.0 , city.1)
print(cityName)
print(cityPopulation)

let groceries = ("bread","onions")
print(groceries.0)
print(groceries.1)
print(type (of: groceries))

var fname="Joe"
var lname="Root"
(fname,lname)=(lname,fname)
print("First name is \(fname) and Last name is \(lname)")



