//
//  ViewController.swift
//  DiscountAppMVC
//
//  Created by Thukivakam,Sravanthi on 10/31/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var amountOL: UITextField!
    
    @IBOutlet weak var discRateOL: UITextField!
    
    var priceAfterDiscount=0.0
    
    @IBAction func calcBtn(_ sender: UIButton) {
        //Read the amount from amountOL
        let amount=Double(amountOL.text!)
        
        //Read the disc rate from discRateOL
        let discRate=Double(discRateOL.text!)
        
        //calculate the price after discount
        priceAfterDiscount=amount! - (amount!*discRate!/100)
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    
        let transition=segue.identifier
        
        if transition=="resultSegue"{
            let destination=segue.destination as! ResultViewController
            
            destination.amount=amountOL.text!
            destination.discRate=discRateOL.text!
            destination.priceAfterDiscount=priceAfterDiscount
            
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

